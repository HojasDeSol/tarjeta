# Hojas De Sol — Tarjeta de Presentación Digital

Tarjeta de presentación digital web para **Gustavo Medina Segovia** (Director de Hojas De Sol, Mtro. en Agronegocios). Diseñada con alta fidelidad a partir del diseño de identidad de marca, optimizada para compartirse mediante un único enlace en WhatsApp, bio de Instagram, redes sociales, código QR y tarjetas NFC.

---

## 📱 Enlaces de Acceso y Demostración

- **Versión de Desarrollo:** [Ver App en Desarrollo](https://ais-dev-njhuqjnztz6ekfttchlvaw-185184809945.us-west1.run.app)
- **Versión Pública / Compartida:** [Abrir Tarjeta Pública](https://ais-pre-njhuqjnztz6ekfttchlvaw-185184809945.us-west1.run.app)

---

## ✨ Funcionalidades Principales

1. **Guardar Contacto en 1 Toque (`.vcf` vCard 3.0)**:
   - Descarga automática del archivo de contacto compatible con la agenda nativa de **iPhone (iOS)** y **Android**.
   - Incluye: Nombre completo, empresa, cargo, grado académico, teléfono móvil directo (`+52 444 207 8942`), correo (`hojasdesolslp@gmail.com`), ubicación (San Luis Potosí) y nota institucional.
2. **Generador y Lector de Código QR**:
   - Generación en tiempo real del código QR que apunta al enlace de la tarjeta.
   - Opción para descargar la imagen del QR en PNG para imprimir en lonas, empaques, tarjetas físicas o stands de expo.
3. **Solicitud de Cotización para Comedores y Restaurantes**:
   - Formulario modal interactivo para operadores de comedores industriales y chefs.
   - Selección de vegetales requeridos y frecuencia de entrega.
   - Enrutamiento directo a WhatsApp con mensaje preformateado o por correo electrónico.
4. **Catálogo de Paquetes para Colaboradores**:
   - Muestra de planes de nutrición y bienestar laboral (*Caja Huerto Familiar*, *Canasta Verde Vital*, *Plan Integral a la Medida*).
   - Botón directo para consultar y cotizar vía WhatsApp.
5. **Redes Sociales Oficiales**:
   - Botón de Facebook con enlace a `hojasdesolmx`.
   - Botón de Instagram con enlace a `@hojasdesolmx`.
6. **Diseño Adaptativo / Responsivo**:
   - **En teléfonos móviles:** Se visualiza como una tarjeta digital nativa táctil de pantalla completa.
   - **En pantallas de escritorio/laptop:** Se presenta enmarcada en el smartphone de borde dorado sobre el fondo agrícola de la huerta, con opción para alternar entre vista directa o vista mockup.

---

## 📂 Estructura del Código

```text
├── index.html                   # Entry point HTML con metadatos SEO y tipografías
├── metadata.json                # Configuración de AI Studio
├── package.json                 # Dependencias y scripts de compilación
├── tsconfig.json                # Configuración TypeScript
├── vite.config.ts               # Configuración Vite + Tailwind CSS
└── src/
    ├── main.tsx                 # Montaje de React 19
    ├── App.tsx                  # Contenedor principal con fondo de campo y controles
    ├── index.css                # Estilos globales y Tailwind v4
    ├── data/
    │   └── cardData.ts          # Datos centrales (contacto, productos, paquetes)
    ├── utils/
    │   └── vcard.ts             # Generador y descargador de archivo vCard (.vcf)
    ├── components/
    │   ├── HojasDeSolLogo.tsx   # Logotipo SVG vectorial oficial (Hojas + Sol)
    │   ├── DigitalCard.tsx      # Componente de la tarjeta digital
    │   ├── QuoteModal.tsx       # Modal de cotización para comedores
    │   ├── PackagesModal.tsx    # Modal de paquetes para colaboradores
    │   ├── ShareModal.tsx       # Modal para compartir con QR dinámico y copiar link
    │   └── ContactModal.tsx     # Opciones de llamada, WhatsApp, email y ubicación
    └── assets/
        └── images/
            ├── gustavo_medina_portrait_*.jpg   # Fotografía de Gustavo Medina
            └── agricultural_field_bg_*.jpg     # Fotografía panorámica del campo
```

---

## 🛠️ Comandos de Desarrollo y Compilación

- **Iniciar servidor de desarrollo:**
  ```bash
  npm run dev
  ```
- **Compilar para producción:**
  ```bash
  npm run build
  ```
- **Verificar tipos TypeScript:**
  ```bash
  npm run lint
  ```
