import React, { useState } from 'react';
import { Share2, Check, ExternalLink } from 'lucide-react';
import { CARD_DATA } from '../data/cardData';
import { HojasDeSolLogo } from './HojasDeSolLogo';
import { downloadVCard } from '../utils/vcard';
import confetti from 'canvas-confetti';

interface DigitalCardProps {
  onOpenQuote: () => void;
  onOpenPackages: () => void;
  onOpenShare: () => void;
  onOpenContact: () => void;
}

export const DigitalCard: React.FC<DigitalCardProps> = ({
  onOpenQuote,
  onOpenPackages,
  onOpenShare,
  onOpenContact,
}) => {
  const [savedContact, setSavedContact] = useState(false);

  const handleSaveContact = () => {
    downloadVCard();
    setSavedContact(true);
    confetti({
      particleCount: 55,
      spread: 75,
      origin: { y: 0.45 },
      colors: ['#1b5e20', '#2e7d32', '#df7d1e', '#f59e0b'],
    });

    setTimeout(() => {
      setSavedContact(false);
    }, 2800);
  };

  return (
    <div className="w-full bg-[#fdfcf7] text-stone-800 rounded-[38px] p-5 sm:p-6 shadow-2xl border border-stone-200/80 flex flex-col justify-between max-w-[420px] mx-auto select-none relative overflow-hidden">
      {/* Subtle organic background gradient warmth */}
      <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-emerald-50/50 via-amber-50/20 to-transparent pointer-events-none" />

      {/* Main Content Area */}
      <div className="relative z-10 space-y-4">
        {/* Brand Logo Header */}
        <div className="pt-1 pb-1">
          <HojasDeSolLogo size="md" />
        </div>

        {/* Profile Lockup */}
        <div 
          onClick={onOpenContact} 
          className="flex items-center gap-4 cursor-pointer group transition-transform active:scale-[0.99] p-1.5 -mx-1.5 rounded-2xl hover:bg-stone-50/80"
          title="Ver opciones de contacto directo"
        >
          {/* Circular Portrait with Gold Ring */}
          <div className="relative shrink-0">
            <div className="w-[96px] h-[96px] sm:w-[106px] sm:h-[106px] rounded-full p-[3px] bg-gradient-to-tr from-[#c49226] via-[#f1ca6a] to-[#c49226] shadow-md group-hover:shadow-lg transition-shadow">
              <div className="w-full h-full rounded-full overflow-hidden bg-stone-100 border-2 border-white">
                <img
                  src={CARD_DATA.person.avatarUrl}
                  alt={CARD_DATA.person.firstName + ' ' + CARD_DATA.person.lastName}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
            </div>
          </div>

          {/* Person Text Details */}
          <div className="flex flex-col justify-center text-left leading-tight min-w-0">
            <h1 className="text-2xl sm:text-[26px] font-extrabold text-[#1b5e20] tracking-tight leading-[1.1]">
              <span>{CARD_DATA.person.firstName}</span>
              <br />
              <span>{CARD_DATA.person.lastName}</span>
            </h1>
            <p className="text-sm sm:text-[15px] font-bold text-[#2e7d32] mt-1 tracking-tight">
              {CARD_DATA.person.title}
            </p>
            <p className="text-xs sm:text-[13px] font-medium text-[#b45309] mt-0.5">
              {CARD_DATA.person.degree}
            </p>
          </div>
        </div>

        {/* Primary CTA: GUARDAR CONTACTO */}
        <div>
          <button
            onClick={handleSaveContact}
            className={`w-full py-3.5 px-4 rounded-2xl font-black text-sm sm:text-base tracking-wider uppercase transition-all duration-200 shadow-md hover:shadow-lg active:scale-[0.98] flex items-center justify-center gap-2 ${
              savedContact
                ? 'bg-emerald-700 text-white'
                : 'bg-gradient-to-r from-[#175d2d] to-[#1c6f37] hover:from-[#134e26] hover:to-[#175d2d] text-white shadow-emerald-900/20'
            }`}
          >
            {savedContact ? (
              <>
                <Check className="w-5 h-5 animate-scale text-white" />
                <span>¡CONTACTO GUARDADO!</span>
              </>
            ) : (
              <span>GUARDAR CONTACTO</span>
            )}
          </button>
        </div>

        {/* Section: NUESTROS PRODUCTOS */}
        <div className="bg-[#f5f8f2] border border-[#d6e3d2] rounded-2xl p-3 sm:p-3.5 shadow-xs">
          <div className="flex items-center justify-center gap-1.5 text-xs sm:text-[13px] font-black text-[#1b5e20] tracking-wider uppercase mb-2">
            <span className="text-sm">🥦</span>
            <span>NUESTROS PRODUCTOS</span>
            <span className="text-sm">🧅🍅</span>
          </div>

          <div className="grid grid-cols-2 gap-x-2 text-xs sm:text-[12.5px] text-stone-800 font-semibold leading-relaxed">
            {/* Left Column */}
            <div className="space-y-1">
              {CARD_DATA.products.columnLeft.map((prod) => (
                <div key={prod.id} className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#1b5e20] shrink-0" />
                  <span className="truncate">{prod.name}</span>
                </div>
              ))}
            </div>

            {/* Right Column */}
            <div className="space-y-1">
              {CARD_DATA.products.columnRight.map((prod) => (
                <div key={prod.id} className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#1b5e20] shrink-0" />
                  <span className="truncate">{prod.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Dual Cards: Comedores vs Colaboradores */}
        <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
          {/* Card 1: PARA COMEDORES Y RESTAURANTES */}
          <div className="bg-[#fbfcfa] border border-[#cddbca] rounded-2xl p-2 sm:p-2.5 flex flex-col justify-between shadow-xs transition-transform hover:-translate-y-0.5">
            {/* Header Badge */}
            <div className="bg-[#56874e] text-white text-[9.5px] sm:text-[10px] font-black tracking-wider uppercase text-center py-1.5 px-1 rounded-xl leading-tight">
              PARA COMEDORES Y RESTAURANTES
            </div>

            {/* Body Description */}
            <p className="text-[10px] sm:text-[11px] text-stone-700 leading-snug text-center my-2 font-normal">
              Abastecimiento integral de vegetales frescos del campo para operadores industriales.
            </p>

            {/* Action Button */}
            <button
              onClick={onOpenQuote}
              className="w-full bg-[#1e5f38] hover:bg-[#184d2d] text-white text-[9.5px] sm:text-[10.5px] font-black tracking-wide uppercase py-1.5 px-1 rounded-xl shadow-xs transition-colors active:scale-95 cursor-pointer"
            >
              SOLICITAR COTIZACIÓN
            </button>
          </div>

          {/* Card 2: PAQUETES PARA COLABORADORES */}
          <div className="bg-[#fffdfa] border border-[#eed7c4] rounded-2xl p-2 sm:p-2.5 flex flex-col justify-between shadow-xs transition-transform hover:-translate-y-0.5">
            {/* Header Badge */}
            <div className="bg-[#e4882c] text-white text-[9.5px] sm:text-[10px] font-black tracking-wider uppercase text-center py-1.5 px-1 rounded-xl leading-tight">
              PAQUETES PARA COLABORADORES
            </div>

            {/* Body Description */}
            <p className="text-[10px] sm:text-[11px] text-stone-700 leading-snug text-center my-2 font-normal">
              Prestación social innovadora: Suministro de vegetales frescos para tus empleados.
            </p>

            {/* Action Button */}
            <button
              onClick={onOpenPackages}
              className="w-full bg-[#df7d1e] hover:bg-[#c66c16] text-white text-[9.5px] sm:text-[10.5px] font-black tracking-wide uppercase py-1.5 px-1 rounded-xl shadow-xs transition-colors active:scale-95 cursor-pointer"
            >
              CONOCER PAQUETES
            </button>
          </div>
        </div>

        {/* Social Media Buttons (Facebook & Instagram) */}
        <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
          {/* Facebook */}
          <a
            href={CARD_DATA.contact.facebookUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-[#1877F2] hover:bg-[#166fe5] text-white py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 shadow-xs font-semibold text-xs tracking-tight transition-all active:scale-95 group"
          >
            {/* Facebook custom f SVG */}
            <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
            </svg>
            <span className="truncate">{CARD_DATA.contact.facebook}</span>
          </a>

          {/* Instagram */}
          <a
            href={CARD_DATA.contact.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-gradient-to-r from-[#833ab4] via-[#fd1d1d] to-[#fcb045] hover:opacity-95 text-white py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 shadow-xs font-semibold text-xs tracking-tight transition-all active:scale-95 group"
          >
            {/* Instagram camera SVG */}
            <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
            </svg>
            <span className="truncate">{CARD_DATA.contact.instagram}</span>
          </a>
        </div>

        {/* COMPARTIR TARJETA Button */}
        <div>
          <button
            onClick={onOpenShare}
            className="w-full bg-[#fdfcf7] hover:bg-[#f1f6ef] border-2 border-[#1b5e20] text-[#1b5e20] py-2.5 px-4 rounded-2xl font-black text-xs sm:text-sm tracking-wider uppercase transition-all shadow-xs hover:shadow-sm active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer"
          >
            <Share2 className="w-4 h-4 text-[#1b5e20]" />
            <span>COMPARTIR TARJETA</span>
          </button>
        </div>
      </div>
    </div>
  );
};
