import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const HojasDeSolLogo: React.FC<LogoProps> = ({ className = '', size = 'md' }) => {
  const iconSizes = {
    sm: 'w-10 h-10',
    md: 'w-14 h-14',
    lg: 'w-20 h-20',
  };

  const textSizes = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-3xl',
  };

  return (
    <div className={`flex flex-col items-center justify-center select-none ${className}`}>
      {/* SVG Icon matching HojasDeSol symbol: Leaves + Sun rays + Curve */}
      <div className={`relative ${iconSizes[size]} mb-1 flex items-center justify-center`}>
        <svg
          viewBox="0 0 120 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-xs"
        >
          {/* Sun with dotted radiant rays between the leaves */}
          <g id="sun-symbol">
            {/* Sun core */}
            <circle cx="62" cy="38" r="9.5" fill="#E58B24" />
            <circle cx="62" cy="38" r="7.5" fill="#F59E0B" />
            
            {/* Radiant ray dots/dashes */}
            {/* Top ray */}
            <circle cx="62" cy="22" r="2.2" fill="#E58B24" />
            {/* Top-right ray */}
            <circle cx="72" cy="25" r="2.2" fill="#E58B24" />
            {/* Right ray */}
            <circle cx="76" cy="34" r="2.2" fill="#E58B24" />
            {/* Top-left ray */}
            <circle cx="52" cy="25" r="2.2" fill="#E58B24" />
            {/* Diagonals */}
            <circle cx="67" cy="23" r="1.8" fill="#F59E0B" />
            <circle cx="57" cy="23" r="1.8" fill="#F59E0B" />
            <circle cx="75" cy="29" r="1.8" fill="#F59E0B" />
          </g>

          {/* Left Leaf (Larger, green, curving up-left) */}
          <path
            d="M58 72 C58 72, 32 68, 26 44 C22 28, 38 15, 52 18 C58 20, 60 28, 59 38 C58 50, 58 72, 58 72 Z"
            fill="url(#leftLeafGrad)"
          />
          {/* Left Leaf Vein Accent */}
          <path
            d="M36 29 C44 32, 52 42, 57 60"
            stroke="#2E6B2C"
            strokeWidth="1.8"
            strokeLinecap="round"
            opacity="0.4"
          />

          {/* Right Leaf (Fresh green, curving up-right) */}
          <path
            d="M60 70 C60 70, 72 62, 82 46 C90 32, 85 20, 75 22 C67 24, 62 32, 61 44 C60 54, 60 70, 60 70 Z"
            fill="url(#rightLeafGrad)"
          />
          {/* Right Leaf Vein Accent */}
          <path
            d="M65 52 C71 42, 76 34, 79 28"
            stroke="#2E6B2C"
            strokeWidth="1.5"
            strokeLinecap="round"
            opacity="0.35"
          />

          {/* Bottom smile curve under leaves */}
          <path
            d="M44 76 C54 84, 68 83, 76 74"
            stroke="#3F7E3B"
            strokeWidth="3.2"
            strokeLinecap="round"
          />

          {/* Gradients */}
          <defs>
            <linearGradient id="leftLeafGrad" x1="28" y1="20" x2="58" y2="70" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#4CAE4F" />
              <stop offset="50%" stopColor="#3F8D3F" />
              <stop offset="100%" stopColor="#2E6B2C" />
            </linearGradient>
            <linearGradient id="rightLeafGrad" x1="62" y1="24" x2="84" y2="65" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#66BB6A" />
              <stop offset="60%" stopColor="#43A047" />
              <stop offset="100%" stopColor="#2E6B2C" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Brand Text: "Hojas" + "DeSol" */}
      <div className={`font-bold tracking-tight flex items-baseline leading-none ${textSizes[size]}`}>
        <span className="text-[#3B7F37] font-extrabold tracking-tight">Hojas</span>
        <span className="text-[#DF8723] font-bold tracking-tight">DeSol</span>
      </div>
    </div>
  );
};
