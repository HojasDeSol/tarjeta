import React, { useState } from 'react';
import { X, Sparkles, Check, Send, HeartHandshake } from 'lucide-react';
import { CARD_DATA, PackageItem } from '../data/cardData';

interface PackagesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PackagesModal: React.FC<PackagesModalProps> = ({ isOpen, onClose }) => {
  const [selectedPkg, setSelectedPkg] = useState<string>(CARD_DATA.packagesList[0].id);

  if (!isOpen) return null;

  const currentPkg = CARD_DATA.packagesList.find((p) => p.id === selectedPkg) || CARD_DATA.packagesList[0];

  const handleConsultWhatsApp = (pkg: PackageItem) => {
    const text = `*CONSULTA DE PAQUETES PARA COLABORADORES - HOJAS DE SOL*\n\n` +
      `Hola Gustavo, me interesa conocer más sobre el paquete corporativo:\n` +
      `📦 *${pkg.title}* (${pkg.subtitle})\n\n` +
      `Nos gustaría implementar esta prestación de vegetales frescos para nuestro equipo de trabajo en la empresa. ¿Podrías brindarnos más detalles y cotización por volumen?\n\n` +
      `_Enviado desde tu tarjeta digital_`;

    const url = `https://wa.me/${CARD_DATA.contact.whatsapp}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden border border-amber-100 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-[#df7d1e] to-[#f59e0b] px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HeartHandshake className="w-5 h-5 text-amber-100" />
            <div>
              <h3 className="font-bold text-lg leading-tight">Paquetes para Colaboradores</h3>
              <p className="text-xs text-amber-100">Prestación Social Saludable e Innovadora</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 transition-colors text-white"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-stone-700">
          <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-3.5 text-xs text-amber-900 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <p>
              Mejora el clima laboral, la nutrición de las familias y la retención de talento entregando canastas de vegetales frescos cosechados el mismo día.
            </p>
          </div>

          {/* Package Selector Pills */}
          <div className="grid grid-cols-3 gap-2">
            {CARD_DATA.packagesList.map((pkg) => (
              <button
                key={pkg.id}
                onClick={() => setSelectedPkg(pkg.id)}
                className={`py-2 px-2 text-xs font-bold rounded-xl border transition-all text-center ${
                  selectedPkg === pkg.id
                    ? 'bg-[#df7d1e] text-white border-[#df7d1e] shadow-sm'
                    : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                }`}
              >
                {pkg.title.replace('Caja ', '').replace('Canasta ', '').replace('Plan ', '')}
              </button>
            ))}
          </div>

          {/* Active Package Details */}
          <div className="border border-amber-200/90 rounded-2xl p-4 bg-gradient-to-b from-amber-50/40 to-white shadow-xs space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md">
                  {currentPkg.tag}
                </span>
                <h4 className="text-base font-bold text-stone-900 mt-1">{currentPkg.title}</h4>
                <p className="text-xs text-stone-500">{currentPkg.subtitle}</p>
              </div>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">{currentPkg.description}</p>

            <div className="space-y-1.5 pt-1">
              <span className="text-[11px] font-bold text-stone-800 uppercase tracking-wide">
                Contenido Típico del Paquete:
              </span>
              <ul className="space-y-1">
                {currentPkg.includes.map((item, idx) => (
                  <li key={idx} className="text-xs text-stone-700 flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-stone-50 p-2.5 rounded-xl border border-stone-200 text-xs text-stone-600">
              <strong className="text-stone-800">Ideal para:</strong> {currentPkg.idealFor}
            </div>
          </div>

          {/* Action Button */}
          <button
            onClick={() => handleConsultWhatsApp(currentPkg)}
            className="w-full bg-[#df7d1e] hover:bg-[#c46914] text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-md transition-all text-sm"
          >
            <Send className="w-4 h-4" />
            Consultar {currentPkg.title} por WhatsApp
          </button>
        </div>
      </div>
    </div>
  );
};
