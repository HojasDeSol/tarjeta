import React, { useState } from 'react';
import { X, Send, Mail, CheckCircle2, Building2, Utensils, Phone, User } from 'lucide-react';
import { CARD_DATA } from '../data/cardData';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QuoteModal: React.FC<QuoteModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [phone, setPhone] = useState('');
  const [frequency, setFrequency] = useState('Diario');
  const [selectedVegetables, setSelectedVegetables] = useState<string[]>([
    'Lechugas Variadas',
    'Tomate y Chile Poblano',
  ]);
  const [notes, setNotes] = useState('');
  const [sentSuccess, setSentSuccess] = useState(false);

  if (!isOpen) return null;

  const vegetablesList = [
    'Lechugas Variadas (Romana / Orejona / Francesa)',
    'Brócoli y Espinacas',
    'Cebollas y Cilantro',
    'Tomate Saladet / Bola',
    'Chile Poblano y Serrano',
    'Zanahoria y Apio',
    'Calabacita y Pepino',
  ];

  const toggleVeg = (item: string) => {
    setSelectedVegetables((prev) =>
      prev.includes(item) ? prev.filter((v) => v !== item) : [...prev, item]
    );
  };

  const handleWhatsAppSend = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `*SOLICITUD DE COTIZACIÓN - HOJAS DE SOL*\n\n` +
      `👤 *Contacto:* ${name || 'Interesado'}\n` +
      `🏢 *Empresa / Comedor:* ${company || 'No especificado'}\n` +
      `📞 *Teléfono:* ${phone || 'No especificado'}\n` +
      `⏱️ *Frecuencia estimada:* ${frequency}\n` +
      `🥗 *Vegetales de interés:*\n${selectedVegetables.map((v) => ` • ${v}`).join('\n')}\n` +
      (notes ? `📝 *Detalles adicionales:* ${notes}\n` : '') +
      `\n_Enviado desde la tarjeta digital de Hojas De Sol_`;

    const whatsappUrl = `https://wa.me/${CARD_DATA.contact.whatsapp}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    setSentSuccess(true);
    setTimeout(() => {
      setSentSuccess(false);
      onClose();
    }, 1800);
  };

  const handleEmailSend = () => {
    const subject = encodeURIComponent(`Solicitud de Cotización para Comedor / Restaurante - ${company || name}`);
    const body = encodeURIComponent(
      `Hola Gustavo,\n\nMe pongo en contacto para solicitar una cotización de vegetales frescos para nuestro comedor / restaurante:\n\n` +
      `Nombre: ${name}\n` +
      `Empresa: ${company}\n` +
      `Teléfono: ${phone}\n` +
      `Frecuencia: ${frequency}\n` +
      `Vegetales requeridos:\n${selectedVegetables.map((v) => `- ${v}`).join('\n')}\n\n` +
      `Comentarios: ${notes}\n\nSaludos cordiales.`
    );
    window.open(`mailto:${CARD_DATA.contact.email}?subject=${subject}&body=${body}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden border border-emerald-100 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-[#1b5e20] to-[#2e7d32] px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Utensils className="w-5 h-5 text-emerald-200" />
            <div>
              <h3 className="font-bold text-lg leading-tight">Solicitar Cotización</h3>
              <p className="text-xs text-emerald-100">Comedores Industriales y Restaurantes</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 transition-colors text-white"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-sm text-stone-700">
          {sentSuccess ? (
            <div className="py-12 text-center space-y-3">
              <CheckCircle2 className="w-16 h-16 text-emerald-600 mx-auto animate-bounce" />
              <h4 className="text-xl font-bold text-stone-900">¡Cotización Generada!</h4>
              <p className="text-stone-600 max-w-xs mx-auto">
                Abriendo WhatsApp para que Gustavo reciba tu solicitud de inmediato.
              </p>
            </div>
          ) : (
            <form onSubmit={handleWhatsAppSend} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wide mb-1 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-emerald-600" /> Tu Nombre / Contacto *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ej. Ing. Carlos Mendoza"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent bg-stone-50 text-stone-900"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wide mb-1 flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-emerald-600" /> Empresa o Restaurante *
                  </label>
                  <input
                    type="text"
                    required
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="Ej. Operadora de Comedores del Bajío"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent bg-stone-50 text-stone-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wide mb-1 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-emerald-600" /> Teléfono / WhatsApp *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Ej. 444 123 4567"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent bg-stone-50 text-stone-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wide mb-1">
                  Frecuencia de Abastecimiento Requerida
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['Diario', 'Semanal (2-3 veces)', 'Quincenal'].map((freq) => (
                    <button
                      key={freq}
                      type="button"
                      onClick={() => setFrequency(freq)}
                      className={`py-2 px-2 text-xs font-semibold rounded-xl border text-center transition-all ${
                        frequency === freq
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                          : 'bg-stone-100 text-stone-700 border-stone-200 hover:bg-stone-200'
                      }`}
                    >
                      {freq}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wide mb-1">
                  Vegetales que Necesitas (Selecciona los necesarios)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-36 overflow-y-auto p-2 bg-stone-50 rounded-xl border border-stone-200">
                  {vegetablesList.map((item) => {
                    const checked = selectedVegetables.includes(item);
                    return (
                      <label
                        key={item}
                        className={`flex items-center gap-2 p-1.5 rounded-lg text-xs cursor-pointer select-none transition-colors ${
                          checked ? 'bg-emerald-100/70 text-emerald-900 font-medium' : 'text-stone-600 hover:bg-stone-100'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => toggleVeg(item)}
                          className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                        />
                        <span>{item}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wide mb-1">
                  Volumen aproximado o requerimientos especiales
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ej. Requerimos 150 kg semanales en zona industrial SLP con entrega a las 6:00 AM..."
                  className="w-full px-3.5 py-2 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent bg-stone-50 text-stone-900 text-xs"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#1b5e20] hover:bg-[#154a1a] text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-md transition-all text-sm"
                >
                  <Send className="w-4 h-4" />
                  Enviar por WhatsApp
                </button>
                <button
                  type="button"
                  onClick={handleEmailSend}
                  className="bg-stone-100 hover:bg-stone-200 text-stone-800 font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-2 border border-stone-300 transition-colors text-sm"
                >
                  <Mail className="w-4 h-4 text-emerald-700" />
                  Enviar por Correo
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
