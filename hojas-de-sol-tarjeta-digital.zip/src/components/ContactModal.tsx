import React from 'react';
import { X, Phone, MessageCircle, Mail, MapPin, Download, Check } from 'lucide-react';
import { CARD_DATA } from '../data/cardData';
import { downloadVCard } from '../utils/vcard';
import confetti from 'canvas-confetti';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handleDownloadAndNotify = () => {
    downloadVCard();
    confetti({
      particleCount: 50,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#1b5e20', '#2e7d32', '#df7d1e'],
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden border border-emerald-100 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#1b5e20] px-5 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Phone className="w-5 h-5 text-emerald-200" />
            <h3 className="font-bold text-base leading-tight">Contacto Directo</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-white/20 transition-colors text-white"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-5 space-y-3">
          <a
            href={`tel:${CARD_DATA.contact.phoneRaw}`}
            className="flex items-center gap-3 p-3 rounded-2xl bg-stone-50 hover:bg-emerald-50 border border-stone-200 hover:border-emerald-300 transition-all group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Phone className="w-5 h-5" />
            </div>
            <div className="text-left flex-1 min-w-0">
              <div className="text-[11px] font-bold text-stone-500 uppercase">Llamada Telefónica</div>
              <div className="text-sm font-bold text-stone-900">{CARD_DATA.contact.phone}</div>
            </div>
          </a>

          <a
            href={`https://wa.me/${CARD_DATA.contact.whatsapp}?text=${encodeURIComponent('Hola Gustavo, te contacto a través de tu tarjeta digital de Hojas De Sol.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 p-3 rounded-2xl bg-stone-50 hover:bg-emerald-50 border border-stone-200 hover:border-emerald-300 transition-all group"
          >
            <div className="w-10 h-10 rounded-xl bg-[#25D366]/20 text-[#128C7E] flex items-center justify-center group-hover:scale-110 transition-transform">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div className="text-left flex-1 min-w-0">
              <div className="text-[11px] font-bold text-stone-500 uppercase">WhatsApp Directo</div>
              <div className="text-sm font-bold text-stone-900">{CARD_DATA.contact.whatsappDisplay}</div>
            </div>
          </a>

          <a
            href={`mailto:${CARD_DATA.contact.email}`}
            className="flex items-center gap-3 p-3 rounded-2xl bg-stone-50 hover:bg-emerald-50 border border-stone-200 hover:border-emerald-300 transition-all group"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Mail className="w-5 h-5" />
            </div>
            <div className="text-left flex-1 min-w-0">
              <div className="text-[11px] font-bold text-stone-500 uppercase">Correo Electrónico</div>
              <div className="text-xs sm:text-sm font-bold text-stone-900 truncate">{CARD_DATA.contact.email}</div>
            </div>
          </a>

          <div className="flex items-center gap-3 p-3 rounded-2xl bg-stone-50 border border-stone-200">
            <div className="w-10 h-10 rounded-xl bg-stone-200 text-stone-700 flex items-center justify-center">
              <MapPin className="w-5 h-5" />
            </div>
            <div className="text-left flex-1 min-w-0">
              <div className="text-[11px] font-bold text-stone-500 uppercase">Ubicación y Operación</div>
              <div className="text-xs font-semibold text-stone-800">{CARD_DATA.contact.location}</div>
            </div>
          </div>

          <button
            onClick={handleDownloadAndNotify}
            className="w-full mt-2 py-3 px-4 bg-[#1b5e20] hover:bg-[#154a1a] text-white font-bold rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 text-xs uppercase tracking-wider"
          >
            <Download className="w-4 h-4" />
            Descargar Tarjeta en tu Teléfono (.vcf)
          </button>
        </div>
      </div>
    </div>
  );
};
