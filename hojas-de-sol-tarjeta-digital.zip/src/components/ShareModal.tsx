import React, { useEffect, useRef, useState } from 'react';
import { X, Copy, Check, Download, Share2, MessageCircle, Send } from 'lucide-react';
import QRCode from 'qrcode';
import confetti from 'canvas-confetti';
import { CARD_DATA } from '../data/cardData';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [copied, setCopied] = useState(false);
  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';

  useEffect(() => {
    if (isOpen && canvasRef.current) {
      QRCode.toCanvas(
        canvasRef.current,
        currentUrl,
        {
          width: 200,
          margin: 1.5,
          color: {
            dark: '#1b5e20',
            light: '#ffffff',
          },
        },
        (error) => {
          if (error) console.error('Error generating QR Code', error);
        }
      );
    }
  }, [isOpen, currentUrl]);

  if (!isOpen) return null;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#1b5e20', '#2e7d32', '#df7d1e', '#e5b044'],
      });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadQR = () => {
    if (!canvasRef.current) return;
    const url = canvasRef.current.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `QR_Tarjeta_HojasDeSol_GustavoMedina.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Gustavo Medina Segovia - Hojas De Sol',
          text: 'Te comparto la tarjeta de presentación digital de Gustavo Medina Segovia (Director de Hojas De Sol). Abastecimiento de vegetales frescos del campo.',
          url: currentUrl,
        });
      } catch {
        // User cancelled or ignored
      }
    } else {
      handleCopy();
    }
  };

  const shareWhatsApp = () => {
    const text = `Hola, te comparto la tarjeta digital de Gustavo Medina Segovia (Hojas De Sol - Vegetales Frescos): ${currentUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden border border-emerald-100 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#1b5e20] px-5 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-emerald-200" />
            <h3 className="font-bold text-base leading-tight">Compartir Tarjeta Digital</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-white/20 transition-colors text-white"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex flex-col items-center text-center space-y-4">
          {/* QR Code Container */}
          <div className="bg-gradient-to-b from-stone-50 to-white p-3 rounded-2xl border-2 border-emerald-100 shadow-sm flex flex-col items-center">
            <canvas ref={canvasRef} className="rounded-xl shadow-xs" />
            <p className="text-[11px] text-stone-500 mt-2 font-medium">
              Escanea para abrir en cualquier celular
            </p>
          </div>

          {/* Quick link copy bar */}
          <div className="w-full">
            <div className="flex items-center gap-1.5 p-1.5 bg-stone-100 rounded-xl border border-stone-200">
              <input
                type="text"
                readOnly
                value={currentUrl}
                className="bg-transparent text-xs text-stone-700 px-2 py-1 flex-1 font-mono truncate focus:outline-none"
              />
              <button
                onClick={handleCopy}
                className={`flex items-center gap-1 px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                  copied
                    ? 'bg-emerald-600 text-white'
                    : 'bg-[#1b5e20] text-white hover:bg-[#144919]'
                }`}
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    ¡Copiado!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    Copiar
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Sharing Buttons */}
          <div className="w-full grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={shareWhatsApp}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-[#25D366] hover:bg-[#20ba5a] text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp
            </button>
            <button
              onClick={handleDownloadQR}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl border border-stone-200 transition-colors"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              Guardar QR
            </button>
          </div>

          {typeof navigator !== 'undefined' && 'share' in navigator && (
            <button
              onClick={handleNativeShare}
              className="w-full py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 transition-colors flex items-center justify-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5 text-emerald-700" />
              Otras Aplicaciones del Teléfono
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
