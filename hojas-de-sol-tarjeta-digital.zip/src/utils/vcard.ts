import { CARD_DATA } from '../data/cardData';

export function generateVCardString(): string {
  const { person, contact } = CARD_DATA;

  // Build standard vCard 3.0 format supported by iOS, Android, macOS and Windows
  const vcardLines = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    `N:${person.lastName};${person.firstName};;;`,
    `FN:${person.firstName} ${person.lastName}`,
    `ORG:${person.company}`,
    `TITLE:${person.title}`,
    `ROLE:${person.degree}`,
    `TEL;TYPE=CELL,VOICE:${contact.phone}`,
    `TEL;TYPE=WORK,VOICE:${contact.phoneRaw}`,
    `EMAIL;TYPE=PREF,INTERNET:${contact.email}`,
    `URL:${window.location.origin}`,
    `ADR;TYPE=WORK:;;;${contact.location};;;`,
    `NOTE:${person.company} - ${person.degree}. Vegetales frescos del campo para comedores industriales y colaboradores.`,
    'END:VCARD',
  ];

  return vcardLines.join('\r\n');
}

export function downloadVCard(): void {
  const vcardText = generateVCardString();
  const blob = new Blob([vcardText], { type: 'text/vcard;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', 'Gustavo_Medina_HojasDeSol.vcf');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  setTimeout(() => {
    URL.revokeObjectURL(url);
  }, 1000);
}
