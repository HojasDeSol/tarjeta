import React, { useState } from 'react';
import { DigitalCard } from './components/DigitalCard';
import { QuoteModal } from './components/QuoteModal';
import { PackagesModal } from './components/PackagesModal';
import { ShareModal } from './components/ShareModal';
import { ContactModal } from './components/ContactModal';
import { CARD_DATA } from './data/cardData';
import { Phone, MessageCircle, QrCode, Smartphone, Sparkles, Check, Copy, Download } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function App() {
  const [isQuoteOpen, setIsQuoteOpen] = useState(false);
  const [isPackagesOpen, setIsPackagesOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [viewMode, setViewMode] = useState<'mockup' | 'clean'>('mockup');

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      confetti({
        particleCount: 35,
        spread: 60,
        origin: { y: 0.1 },
        colors: ['#1b5e20', '#df7d1e', '#e5b044'],
      });
      setTimeout(() => setCopiedLink(false), 2000);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <main className="min-h-screen w-full relative flex flex-col items-center justify-center font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Background Layer: Farm background matching the reference photo */}
      <div 
        className="fixed inset-0 z-0 bg-cover bg-center bg-no-repeat transition-all duration-700 filter brightness-95"
        style={{
          backgroundImage: `url(${CARD_DATA.person.backgroundUrl})`,
        }}
      >
        {/* Soft overlay gradient to ensure depth and contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/25 to-black/40 backdrop-blur-[2px]" />
      </div>

      {/* Floating Top Bar for Desktop / Browser View */}
      <header className="relative z-30 w-full max-w-4xl px-4 pt-4 pb-2 flex items-center justify-between text-white">
        <div className="flex items-center gap-2 bg-stone-900/70 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-white/15 shadow-lg">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-semibold tracking-wide">Tarjeta Digital Oficial</span>
          <span className="text-stone-400 text-xs hidden sm:inline">· Hojas De Sol</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Download ZIP Button */}
          <a
            href="/hojas-de-sol-tarjeta-digital.zip"
            download="hojas-de-sol-tarjeta-digital.zip"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-900/80 hover:bg-stone-900 backdrop-blur-md rounded-full border border-amber-400/30 text-xs font-semibold text-amber-200 transition-colors shadow-xs"
            title="Descargar código completo en archivo .ZIP"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Descargar ZIP</span>
          </a>

          {/* View toggle for testing mockup vs raw mobile */}
          <button
            onClick={() => setViewMode(viewMode === 'mockup' ? 'clean' : 'mockup')}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-stone-900/70 hover:bg-stone-900/90 backdrop-blur-md rounded-full border border-white/15 text-xs font-medium text-stone-200 transition-colors"
            title="Alternar entre vista con marco de teléfono o tarjeta directa"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span>{viewMode === 'mockup' ? 'Ver Tarjeta Directa' : 'Ver Marco Móvil'}</span>
          </button>

          {/* Quick Copy Link Button */}
          <button
            onClick={handleCopyLink}
            className={`flex items-center gap-1.5 px-3 py-1.5 backdrop-blur-md rounded-full text-xs font-bold transition-all shadow-md ${
              copiedLink
                ? 'bg-emerald-600 text-white'
                : 'bg-emerald-700/90 hover:bg-emerald-600 text-white border border-emerald-400/30'
            }`}
          >
            {copiedLink ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>¡Enlace Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copiar Enlace</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Card Presentation Container */}
      <div className="relative z-20 w-full flex-1 flex items-center justify-center p-3 sm:p-6 my-auto">
        {viewMode === 'mockup' ? (
          /* Phone Mockup Frame (replicating the uploaded reference phone frame) */
          <div className="relative w-full max-w-[428px] mx-auto">
            {/* Phone Bezel Outer (Gold / Champagne Metallic Finish like the image) */}
            <div className="relative rounded-[50px] p-[10px] bg-gradient-to-b from-[#e5cf98] via-[#a38043] to-[#e8d5a7] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7),0_0_0_1px_rgba(255,255,255,0.2)]">
              {/* Phone Inner Black Border */}
              <div className="rounded-[42px] p-[2.5px] bg-[#1a1815]">
                {/* Phone Glass Display Screen */}
                <div className="relative rounded-[40px] overflow-hidden bg-[#fdfcf7] shadow-inner">
                  {/* Speaker Ear Notch / Dynamic Island simulation */}
                  <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-4 bg-black/90 rounded-full z-40 flex items-center justify-center pointer-events-none">
                    <div className="w-10 h-1 bg-stone-700 rounded-full" />
                    <div className="w-2.5 h-2.5 rounded-full bg-stone-900 border border-stone-800 ml-3" />
                  </div>

                  {/* Top spacing for phone notch */}
                  <div className="pt-4">
                    <DigitalCard
                      onOpenQuote={() => setIsQuoteOpen(true)}
                      onOpenPackages={() => setIsPackagesOpen(true)}
                      onOpenShare={() => setIsShareOpen(true)}
                      onOpenContact={() => setIsContactOpen(true)}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Clean Direct Card View (full screen mobile layout) */
          <div className="w-full max-w-[420px] mx-auto animate-in fade-in zoom-in-95 duration-200">
            <DigitalCard
              onOpenQuote={() => setIsQuoteOpen(true)}
              onOpenPackages={() => setIsPackagesOpen(true)}
              onOpenShare={() => setIsShareOpen(true)}
              onOpenContact={() => setIsContactOpen(true)}
            />
          </div>
        )}
      </div>

      {/* Floating Bottom Action Strip (for rapid mobile access & sharing) */}
      <footer className="relative z-30 w-full max-w-md px-4 pb-4 pt-1 flex items-center justify-center gap-2">
        <a
          href={`tel:${CARD_DATA.contact.phoneRaw}`}
          className="flex-1 py-2.5 px-3 bg-stone-900/80 hover:bg-stone-900 backdrop-blur-md rounded-2xl border border-white/20 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95"
        >
          <Phone className="w-4 h-4 text-emerald-400" />
          <span>Llamar</span>
        </a>

        <a
          href={`https://wa.me/${CARD_DATA.contact.whatsapp}?text=${encodeURIComponent('Hola Gustavo, te contacto desde tu tarjeta digital.')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-2.5 px-3 bg-[#25D366]/90 hover:bg-[#25D366] text-white text-xs font-bold rounded-2xl shadow-lg flex items-center justify-center gap-2 transition-all active:scale-95"
        >
          <MessageCircle className="w-4 h-4" />
          <span>WhatsApp</span>
        </a>

        <button
          onClick={() => setIsShareOpen(true)}
          className="py-2.5 px-3.5 bg-stone-900/80 hover:bg-stone-900 backdrop-blur-md rounded-2xl border border-white/20 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-lg transition-all active:scale-95"
          title="Ver código QR para compartir"
        >
          <QrCode className="w-4 h-4 text-amber-400" />
          <span className="hidden sm:inline">QR</span>
        </button>
      </footer>

      {/* Interactive Modals */}
      <QuoteModal isOpen={isQuoteOpen} onClose={() => setIsQuoteOpen(false)} />
      <PackagesModal isOpen={isPackagesOpen} onClose={() => setIsPackagesOpen(false)} />
      <ShareModal isOpen={isShareOpen} onClose={() => setIsShareOpen(false)} />
      <ContactModal isOpen={isContactOpen} onClose={() => setIsContactOpen(false)} />
    </main>
  );
}
