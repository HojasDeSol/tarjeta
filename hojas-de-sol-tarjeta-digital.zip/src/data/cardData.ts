export interface ProductItem {
  id: string;
  name: string;
  emoji?: string;
}

export interface PackageItem {
  id: string;
  title: string;
  subtitle: string;
  tag: string;
  description: string;
  includes: string[];
  idealFor: string;
}

export const CARD_DATA = {
  person: {
    firstName: 'Gustavo',
    lastName: 'Medina Segovia',
    title: 'Director, Hojas De Sol',
    degree: 'Mtro. en Agronegocios',
    company: 'Hojas De Sol',
    avatarUrl: '/src/assets/images/gustavo_medina_portrait_1792386558360.jpg',
    backgroundUrl: '/src/assets/images/agricultural_field_bg_1792386559125.jpg',
  },
  contact: {
    phone: '+52 444 207 8942',
    phoneRaw: '+524442078942',
    whatsapp: '524442078942',
    whatsappDisplay: '444 207 8942',
    email: 'hojasdesolslp@gmail.com',
    location: 'San Luis Potosí, S.L.P., México',
    website: 'https://hojasdesol.com.mx',
    facebook: 'hojasdesolmx',
    facebookUrl: 'https://www.facebook.com/hojasdesolmx',
    instagram: '@hojasdesolmx',
    instagramUrl: 'https://www.instagram.com/hojasdesolmx',
  },
  products: {
    title: 'NUESTROS PRODUCTOS',
    columnLeft: [
      { id: '1', name: 'Lechugas Variadas' },
      { id: '2', name: 'Brócoli y Espinacas' },
      { id: '3', name: 'Cebollas y Cilantro' },
    ],
    columnRight: [
      { id: '4', name: 'Tomate y Chile Poblano' },
      { id: '5', name: 'Y más... 🌶️🫑🥬' },
    ],
  },
  services: {
    commercial: {
      badge: 'PARA COMEDORES Y RESTAURANTES',
      description: 'Abastecimiento integral de vegetales frescos del campo para operadores industriales.',
      buttonText: 'SOLICITAR COTIZACIÓN',
    },
    collaborators: {
      badge: 'PAQUETES PARA COLABORADORES',
      description: 'Prestación social innovadora: Suministro de vegetales frescos para tus empleados.',
      buttonText: 'CONOCER PAQUETES',
    },
  },
  packagesList: [
    {
      id: 'familiar',
      title: 'Caja Huerto Familiar',
      subtitle: 'Nutrición esencial para el hogar',
      tag: 'Más Solicitado',
      description: 'Selección balanceada de vegetales de temporada recién cosechados para una familia de 4 personas.',
      includes: ['Lechugas variadas (Romana / Orejona)', 'Jitomate Saladet y Tomate bola', 'Cebollas frescas y cilantro', 'Brócoli o espinacas seleccionadas', 'Chiles poblanos o serranos'],
      idealFor: 'Empresas que buscan fomentar hábitos saludables en sus colaboradores.',
    },
    {
      id: 'vital',
      title: 'Canasta Verde Vital',
      subtitle: 'Enfoque en salud y bienestar',
      tag: 'Especial Saludable',
      description: 'Variedad de hojas verdes, crucíferas y vegetales ricos en antioxidantes directo del campo potosino.',
      includes: ['Mix de lechugas gourmet', 'Espinacas tiernas baby', 'Brócoli fresco de exportación', 'Hierbas aromáticas y cilantro', 'Apio y vegetales crujientes'],
      idealFor: 'Programas corporativos de bienestar (Wellness corporativo).',
    },
    {
      id: 'empresarial',
      title: 'Plan Integral a la Medida',
      subtitle: 'Volumen y logística programada',
      tag: 'Corporativo',
      description: 'Esquemas de entrega semanal o quincenal con logística directa en centros de trabajo o plantas industriales.',
      includes: ['Empaque individualizado con código de empleado', 'Control de calidad e inocuidad garantizada', 'Precios preferenciales por volumen corporativo', 'Facturación formal y crédito empresarial'],
      idealFor: 'Empresas con más de 50 colaboradores en San Luis Potosí y Bajío.',
    },
  ] as PackageItem[],
};
